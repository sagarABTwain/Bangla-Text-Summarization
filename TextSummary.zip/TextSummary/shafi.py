# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 15:16:20 2018

@author: Safi Ullah  
"""
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.pyplot as pltt
import math
from sentTokenizer import sentTokenizing
from wordConverter import word
from posTagger import pos
from banglaStemmer import Stemmer
import codecs

with codecs.open("input.txt",'r',encoding="utf-8") as myfile:
    text= myfile.read()
    
   
def makePara(data):
    two=[]
    sent=sentTokenizing().sentTokenize(data)
    two.append(sent)
    two.append(word().sentToWord(sent))
    print(two[1])
    return two
def takingAdcNoun(fromWhichSent):
    nounsToStemm=[]
    Adjs=[]
    Nouns=[]
    for i in fromWhichSent:
        a=pos().posNoun(i)
        # i mane a single word in a sentence 
        if a:
            nounsToStemm.append(a)
        b=pos().posAdj(i)
        if b:
            Adjs.append(b)
    #print(nounsToStemm)
    #print(Adjs)
    for i in nounsToStemm:
        Nouns.append(Stemmer().wordStem(i))
    retAdcNouns=Nouns+Adjs
    return retAdcNouns

def createCostMatrix(havingAN):
    lenOfSide=len(havingAN)
    cost=[[0 for i in range(lenOfSide)] for j in range(lenOfSide)]
    #print(lenOfSide,"--------------------")
    # having lenOfSide is the total sentence 
    for i in range(lenOfSide):
        for j in range(i+1,lenOfSide):
            
            cst=set(havingAN[i]).intersection(havingAN[j]) 
            
            cost[i][j]= len(cst)
            cost[j][i]= len(cst)
    #print(cst,"---------------------------")
    drawGraph(cost,lenOfSide)
    return cost

def scoreCal(node,degree,Pr):
    sm=0
    N=len(degree)
    d=0.85
    for i in node:
        sm+=Pr[i]/(1.0*degree[i])
    return N/d+(1.0-d)*sm


def drawGraph(getCost,getlenOfSide): #58
    g= nx.Graph()
    getNodes=nx.path_graph(getlenOfSide) 
    g.add_nodes_from(getNodes)
    for i in range(getlenOfSide):
        for j in range(getlenOfSide):
            if i!=j and getCost[i][j]:
                g.add_edge(i,j)
    nx.draw_networkx(g)
    figure = plt.gcf() # get current figure
    figure.set_size_inches(9,6)
    plt.savefig("shafi.png")
    plt.show()
    
#if __name__=="__main__":
two = makePara(text)
sent=two[0]
splitingSent=two[1]



recAdcNoun=[]
lenOfPara=len(sent)
for i in range(lenOfPara):
    recAdcNoun.append(takingAdcNoun(splitingSent[i]))
    #print(recAdcNoun)
costMatrix = createCostMatrix(recAdcNoun)
adcNode=[]
degree=[]
for i in range(lenOfPara):
    nodes=[]
    for j in range(lenOfPara):
        if costMatrix[i][j]:
            nodes.append(j)
    adcNode.append(nodes)
    
    
    degree.append(sum(costMatrix[i]))
    
    print(i,nodes,degree[i])
    
Pr=[0.0]*lenOfPara

it=1000
while it:
    for i in range(lenOfPara):
        Pr[i]=scoreCal(adcNode[i],degree,Pr)
        #print(i,'has',Pr[i])
    it-=1

afterSort=[]
sm=0
miu=sum(Pr)/len(Pr)
for i in range(lenOfPara):
    sm+=(Pr[i]-miu)**2
    afterSort.append((i,Pr[i])) 
sigma=(sm/len(Pr))**0.5

print("\n\nGetting sentence number after sorting with their scores")
print("----------------------------------------------------------------------")
afterSort.sort(key=lambda x:x[1])
afterSort.reverse()
takingSent=[]
if(lenOfPara<30):
    takingWhichSent=takingWhichSent=math.ceil(lenOfPara/3)
else:
   
    takingWhichSent=10
print(takingWhichSent)
forcluster=[]
for i in range(len(afterSort)):
    print(afterSort[i],"   ",i)
    forcluster.append(afterSort[i][0])
    if i<takingWhichSent:
        #after sort[i][0] mane 1ta sentence er number. 
        takingSent.append(afterSort[i][0])

print("\n\nGetting Summary")

print("-------------------------------------------------------------")

#with open(filepath, 'w') as textfile:
takingSent.sort()
for i in takingSent:
    #textfile.write("{}".join(sent[i]))
    print(sent[i],end=' ')
#textfile.close()
print("\n------------------------------------------------------------")
print("\n\n Comments on the indivizual Groups described below :")
count=0
centerr=230
center0 =240
center1= 250
center2= 260
center3= 270
center4= 280
center5= 290
center6= 300
center7= 310
center8= 320 
center9=330
center10=340

cr=[]
c0=[]
c1=[]
c2=[]
c3=[]
c4=[]  
c5=[]
c6=[]
c7=[]
c8=[]
c9=[]
c10=[]

sr=0
s0=0
s1=0
s2=0
s3=0
s4=0
s5=0
s6=0
s7=0
s8=0
s9=0
check=1
avg=0
dev=[]
sentno=[]
avg = sum(Pr)/lenOfPara
g=0
x=[]
y=[]
while(check==1):
    
    for i in range(lenOfPara):
        #avg+=Pr[i]
        if(g==0):
            dev.append(abs(Pr[i]-avg))
            sentno.append(i)
            
        mr=centerr-Pr[i]
        if(mr<0):
            mr=mr*(-1)
        m0=center0-Pr[i]
        if(m0<0):
            m0=m0*(-1)
        m1 = center1-Pr[i]
        if m1<0:
            m1=m1*(-1)    
        m2 = center2-Pr[i]
        if m2<0:
            m2=m2*(-1)
        m3 = center3-Pr[i]
        if m3<0:
            m3=m3*(-1)
        m4 = center4-Pr[i]
        if m4<0: 
            m4=m4*(-1)
        m5 = center5-Pr[i]
        if m5<0:
            m5=m5*(-1)
        m6 = center6-Pr[i]
        if m6<0:
            m6=m6*(-1)
        m7 = center7-Pr[i]
        if m7<0:
            m7=m7*(-1)
        m8 = center8-Pr[i]
        if m8<0:
            m8=m8*(-1)
        m9=center9-Pr[i]
        if(m9<0):
            
            m9=m9*(-1)
        m10=center10-Pr[i]
        if(m10<0):
            
            m10=m10*(-1)
        
            
        m = min(mr,m0,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10)
        if(m==mr):
            cr.append((i,Pr[i]))
        if(m==m0):
            c0.append((i,Pr[i]))
        
        elif(m==m1):
            c1.append((i,Pr[i]))
        elif(m==m2):
            c2.append((i,Pr[i]))
        elif(m==m3):
            c3.append((i,Pr[i]))
        elif(m==m4):
            c4.append((i,Pr[i]))
        elif(m==m5):
            c5.append((i,Pr[i]))
        elif(m==m6):
            c6.append((i,Pr[i]))
        elif(m==m7):
            c7.append((i,Pr[i])) 
        elif(m==m8):
            c8.append((i,Pr[i]))
        elif(m==m9):
            
            c9.append((i,Pr[i]))
        else:
            c10.append((i,Pr[i]))
    g=g+1
    sumr=0
    sum0=0
    sum1=0
    sum2=0
    sum3=0
    sum4=0
    sum5=0
    sum6=0
    sum7=0
    sum8=0
    sum9=0
    sum10=0
    #if(len(c)):
    #for a, b in cr:
       # sumr+=b        
    #for a, b in c0:
       # sum0+=b          
    for a, b in c1:
        sum1+=b
    for a, b in c2:
        sum2+=b
    for a, b in c3:
        sum3+=b
    for a, b in c4:
        sum4+=b
    for a, b in c5:
        sum5+=b
    for a, b in c6:
        sum6+=b
    for a, b in c7:
        sum7+=b
    for a, b in c8:
        sum8+=b
    for a, b in c9:
        sum9+=b 
    for a, b in c10:
        sum10+=b 
           
        
    if len(cr)==0:
        cr.append(240)
    sumr = sumr/len(cr)
    
    
    if len(c0)==0:
        c0.append(240)
    sum0=sum0/len(c0)
    if len(c1)==0:
        c1.append(240)         
    sum1=sum1/len(c1)
    if len(c2)==0:
        c2.append(240)
    sum2=sum2/len(c2)
    if len(c3)==0:
        c3.append(240)
    sum3=sum3/len(c3)
    if len(c4)==0:
        c4.append(240)         
    sum4=sum4/len(c4)
    if len(c5)==0:
        c5.append(240)
    sum5=sum5/len(c5)
    if len(c6)==0:
        c6.append(240)
    sum6=sum6/len(c6)
    if len(c7)==0:
        c7.append(240)
    sum7=sum7/len(c7)
    if len(c8)==0:
        c8.append(240)
    sum8=sum8/len(c8)
    if len(c9)==0:
        c9.append(240)
    sum9=sum9/len(c9)
    
    if(count==0):
        sr=sumr
        s0=sum0
        s1=sum1
        s2=sum2
        s3=sum3
        s4=sum4
        s5=sum5
        s6=sum6
        s7=sum7
        s8=sum8
        s9=sum9
        s10=sum10
        count=count+1
    else:
        if(s1==sum1 and s2==sum2 and s3==sum3 and s4==sum4 and sr==sumr and s10==sum10):
            if(s5==sum5 and s6==sum6 and s7==sum7 and s8==sum8 and s9==sum9):
                check=0
                x=[len(c1),len(c2),len(c3),len(c4),len(c5),len(c6),len(c7),len(c8),len(c9),len(c10)]
                y=[s1,s2,s3,s4,s5,s6,s7,s8,s9,s10]
                '''plt.plot(y,x,color='green')
                plt.xlabel("Score of Sentences")
                plt.ylabel("No of Sentences")
                plt.title("NO vs Score")
                plt.show()'''
                
                mini=min(Pr)
                maxi=max(Pr)
                avg = sum(Pr)/lenOfPara
                
                                         
                pltt.xlabel(" No of sentences ")
                pltt.ylabel(" Sentence's Scores ")
                pltt.axhline(y=avg+2*sigma,xmin=0,xmax=lenOfPara+2,c="red",linewidth=3.0,zorder=0)
                pltt.axhline(y=avg+sigma,xmin=0,xmax=lenOfPara+2,c="red",linewidth=3.0,zorder=0)
                pltt.axhline(y=avg,xmin=0,xmax=lenOfPara+2,c="green",linewidth=3.0,zorder=0)
                pltt.axhline(y=avg-sigma,xmin=0,xmax=lenOfPara+2,c="red",linewidth=3.0,zorder=0)
                pltt.scatter(sentno,Pr) 
                pltt.legend("Sentences and its corresponding Score ")
                pltt.show()
                
                pltt.axhline(y=0,xmin=0,xmax=lenOfPara+2,c="red",linewidth=3.0,zorder=0)
                plt.scatter(sentno,dev)
                plt.ylabel(" Deviance of a sentence from Mean ")
                plt.xlabel(" no. of Sentence ")
                plt.show()
                #print("And Finally a group consist of ",len(c1)," sentences opines that ", sent[c1[0][0]])
                               
        else:
            s1=sum1
            s2=sum2
            s3=sum3
            s4=sum4
            s5=sum5
            s6=sum6
            s7=sum7
            s8=sum8
            s9=sum9
            s10=sum10
            count=count+1
            c1=[]
            c2=[]
            c3=[]
            c4=[]  
            c5=[]
            c6=[]
            c7=[]
            c8=[]
            c9=[]
            c10=[]

class PRA:
    def retNSent(self):
        global takingSent
        return takingSent
    def retXY(self):
        global x,y
        xy=[]
        xy.append(x)
        xy.append(y)
        return xy
    def retSent(self):
        global sent
        return sent
