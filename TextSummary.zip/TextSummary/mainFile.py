# -*- coding: utf-8 -*-
"""
Created on Thu Feb 15 23:30:59 2018

@author: Sofi Ullah
"""
import matplotlib.pyplot as plt
from sagar import RBA
from shafi import PRA
def graphShow(xyPRA,xyRBA):
    xPRA=xyPRA[0]
    yPRA=xyPRA[1]
    xRBA=xyRBA[0]
    yRBA=xyRBA[1]
    plt.plot(yPRA,xPRA,color='green',marker='o',label='PRA')
    plt.plot(yRBA,xRBA,color='red',marker='o',label='RBA')
    plt.xlabel("Score of Sentences")
    plt.ylabel("No of Sentences")
    plt.title("NO vs Score")
    plt.legend()
    plt.show()
if __name__=="__main__":
    sent=PRA().retSent()
    takingSentPRA=PRA().retNSent()
    takingSentRBA=RBA().retNSent()
    xyPRA=PRA().retXY()
    xyRBA=RBA().retXY()
    output=set(takingSentPRA).intersection(takingSentRBA)
    print('\nOutput Of document')
    print('-----------------------------------------------')
    for i in output:
        print(sent[i],end='')
    print('\n')
    graphShow(xyPRA,xyRBA)