# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 16:40:30 2018

@author: Safi ullah
"""

import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.pyplot as pltt
import matplotlib.pyplot as plt3
import math
from sentTokenizer import sentTokenizing
from wordConverter import word
from posTagger import pos
from banglaStemmer import Stemmer
import codecs
with codecs.open("input.txt",'r',encoding="utf-8") as myfile:
    text= myfile.read()
def makePara(data):
    two=[]
    sent=sentTokenizing().sentTokenize(data)
    two.append(sent)
    two.append(word().sentToWord(sent))
    return two
def takingNoun(words):
    Nouns=[]
    poitionOfNouns=[]
    for i in words:
        a=pos().posNoun(i)
        if a:
            poitionOfNouns.append(words.index(a))
            Nouns.append(Stemmer().wordStem(a))
    ret=[]
    ret.append(poitionOfNouns)
    ret.append(Nouns)
    #print(poitionOfNouns,Nouns)
    return ret

#if __name__=="__main__":
two=makePara(text)
sent=two[0]
splitingSent=two[1]
lenOfPara=len(sent)
allNouns=[]
rec=[]
for i in range(lenOfPara):
    rec=takingNoun(splitingSent[i])
    for j in range(len(rec[0])):
        splitingSent[i][rec[0][j]]=rec[1][j]
        allNouns.append(rec[1][j])
nouns=[]
for i in set(allNouns):
    nouns.append(i)
print ("\n\nSplitting sentence")
print("------------------------------------------------------------")
LengthOfPara=len(sent)
NoOfNoun=len(nouns)
'''for i in range(LengthOfPara):
    print(sent[i])
    print(splitingSent[i])'''
EachSent=[]
for i in range(LengthOfPara):
    save = []
    for j in nouns:
        if j in splitingSent[i]:
            save.append(j)
    EachSent.append(save)

print ("\n\nDistance calculation")
print("------------------------------------------------------------")
dis=[]
g=nx.Graph()
for i in range(LengthOfPara):
    el=len(EachSent[i])
    if el>1:
        #print el, EachSent[i]
        for j in range(el):
            for k in range(j+1,el):
                pot=[]
                p=nouns.index(EachSent[i][j])
                pot.append(p)
                q = nouns.index(EachSent[i][k])
                pot.append(q)
                d=abs(splitingSent[i].index(EachSent[i][j])-splitingSent[i].index(EachSent[i][k]))
                pot.append(d)
                dis.append(pot)
                #print ("dist(",nouns[p],",",nouns[q],")= ",d)
               # g.add_node(nouns[p])
               # g.add_node(nouns[q])
               # g.add_edge(nouns[p],nouns[q])
                g.add_node(p)
                g.add_node(q)
                g.add_edge(p,q)
nx.draw_networkx(g)
figure = plt.gcf() # get current figure
figure.set_size_inches(12,8)
plt.savefig("test.png")
plt.show()

print ("\n\nRelevance calculation")
print("------------------------------------------------------------")
Rel=[]
for i in range(NoOfNoun):
    sm=0
    for j in range(len(dis)):
        if dis[j][0]==i or dis[j][1]==i:
            sm+=dis[j][2]
    #keepRel=[]
    #keepRel.append(i)
    #keepRel.append(sum)
    Rel.append(sm)
    print ("Relavance of",nouns[i],"is :", Rel[i])

print ("\n\nSentence scoring calculation")
print("------------------------------------------------------------")
scoreOfEachSent=[]
for i in range(LengthOfPara):
    el = len(EachSent[i])
    total=0
    if el > 1:
        for j in range(el):
            index=nouns.index(EachSent[i][j])
            total+=Rel[index]
        keepSent = []
        keepSent.append(i)
        keepSent.append(total)
        #print keepSent
        scoreOfEachSent.append(keepSent)

afterSort=[]

l=len(scoreOfEachSent)
for i in range(l):
    afterSort.append((scoreOfEachSent[i][0],scoreOfEachSent[i][1]))
    print (scoreOfEachSent[i][0],"no. sentence having scores :",scoreOfEachSent[i][1])
   
sentNo=[]
sentScore=[]
for i in  range(l):
    sentNo.append(scoreOfEachSent[i][0])
    sentScore.append(scoreOfEachSent[i][1]*339/26213)
    
miu=sum(sentScore)/len(sentScore)
sm=0
for i in sentScore:
    sm+=(i-miu)**2
sigma=(sm/len(sentScore))**0.5
   
#print(" the value of l is ",l,"len of sentscore ",len(sentScore))
#plt.scatter(sentNo,sentScore,color='red',marker='o') 
plt.show()
print(" NOw print the another graph ")
avg = sum(sentScore)/len(sentNo)
plt3.scatter(sentNo,sentScore,marker='o')
plt3.axhline(y=avg+2*sigma,xmin=0,xmax=len(sentNo)+2,c="red",linewidth=3)
plt3.axhline(y=avg+sigma,xmin=0,xmax=len(sentNo)+2,c="red",linewidth=3)
plt3.axhline(y=avg,xmin=0,xmax=len(sentNo)+2,c="green",linewidth=3)
plt3.axhline(y=avg-sigma,xmin=0,xmax=len(sentNo)+2,c="red",linewidth=3)
plt3.xlabel("No of sentences ")
plt3.ylabel("Sentences scores ")
figure = plt3.gcf() # get current figure
figure.set_size_inches(9,6)
plt3.savefig("deviance.png")
plt3.show()


plt3.show()
print("\n\nGetting sentence number after sorting with their scores")
print("------------------------------------------------")

deviance=[]
for i in sentScore:
    deviance.append(abs(i-avg))
plt.scatter(sentNo,deviance,marker='o') 
plt.axhline(y=0,xmin=0,xmax=len(sentNo)+2,c="red",linewidth=3)
plt.xlabel("No of sentences ")
plt.ylabel("deviance from mean ")
figure = plt.gcf() # get current figure
figure.set_size_inches(9,6)
plt.savefig("mean.png")
plt.show()

Pr=sentScore[:]
print(len(Pr))
count=0

center1= 0
center2= 34
center3= 68
center4= 102
center5= 136
center6= 170
center7= 204
center8= 238
center9=272
center10=306
center11=340

c0=[]
c1=[]
c2=[]
c3=[]
c4=[]  
c5=[]
c6=[]
c7=[]
c8=[]
c9=[]
c10=[]
c11=[]
cc=[]
sr=0
s0=0
s1=0
s2=0
s3=0
s4=0
s5=0
s6=0
s7=0
s8=0
s9=0
s10=0
s11=0
check=1
avg=0
dev=[]
sentno=[]
avg = sum(Pr)/lenOfPara
g=0
x=[]
y=[]
while(check==1):
    
    for i in range(len(Pr)):
        #avg+=Pr[i]
       # if(g==0):
            #dev.append(abs(Pr[i]-avg))
            #sentno.append(i)
            
        m1 = center1-Pr[i]
        if m1<0:
            m1=m1*(-1)    
        m2 = center2-Pr[i]
        if m2<0:
            m2=m2*(-1)
        m3 = center3-Pr[i]
        if m3<0:
            m3=m3*(-1)
        m4 = center4-Pr[i]
        if m4<0: 
            m4=m4*(-1)
        m5 = center5-Pr[i]
        if m5<0:
            m5=m5*(-1)
        m6 = center6-Pr[i]
        if m6<0:
            m6=m6*(-1)
        m7 = center7-Pr[i]
        if m7<0:
            m7=m7*(-1)
        m8 = center8-Pr[i]
        if m8<0:
            m8=m8*(-1)
        m9=center9-Pr[i]
        if(m9<0):
            
            m9=m9*(-1)
        m10=center10-Pr[i]
        if(m10<0):            
            m10=m10*(-1)
        m11=center10-Pr[i]
        if(m11<0):
            m11=m11*(-1)
        
        
            
        m = min(m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11)            
        if(m==m1):
            c1.append((i,Pr[i]))
        elif(m==m2):
            c2.append((i,Pr[i]))
        elif(m==m3):
            c3.append((i,Pr[i]))
        elif(m==m4):
            c4.append((i,Pr[i]))
        elif(m==m5):
            c5.append((i,Pr[i]))
        elif(m==m6):
            c6.append((i,Pr[i]))
        elif(m==m7):
            c7.append((i,Pr[i])) 
        elif(m==m8):
            c8.append((i,Pr[i]))
        elif(m==m9):
            
            c9.append((i,Pr[i]))
        elif(m==m10):
            
            c10.append((i,Pr[i]))   
        else:
            c11.append((i,Pr[i]))
            
    g=g+1
    sumr=0
    sum0=0
    sum1=0
    sum2=0
    sum3=0
    sum4=0
    sum5=0
    sum6=0
    sum7=0
    sum8=0
    sum9=0
    sum10=0
    sum11=0
    #if(len(c)):
    #for a, b in cr:
       # sumr+=b        
    #for a, b in c0:
       # sum0+=b          
    for i in range(len(c1)):
        sum1+=c1[i][1]
    for i in range(len(c2)):
        sum2+=c2[i][1]
    for i in range(len(c3)):      
        sum3+=c3[i][1]
    for i in range(len(c4)):
        sum4+=c4[i][1]
    for i in range(len(c5)):
        sum5+=c5[i][1]
    for i in range(len(c6)):
        sum6+=c6[i][1]
    for i in range(len(c7)):
        sum7+=c7[i][1]
    for i in range(len(c8)):
        sum8+=c8[i][1]
    for i in range(len(c9)):
        sum9+=c9[i][1]
    for i in range(len(c10)):
        sum10+=c10[i][1] 
    for i in range(len(c11)):
        sum11+=c11[i][1]            
        

    if len(c1)!=0:
        sum1=sum1/len(c1)         
    
    if len(c2):
        sum2=sum2/len(c2)
    
    if len(c3):
        sum3=sum3/len(c3)
    if len(c4):
        sum4=sum4/len(c4)
    if len(c5):
        #c5.append((1,240))
        sum5=sum5/len(c5)
    if len(c6):
        #c6.append((1,240))
        sum6=sum6/len(c6)
    if len(c7):
        #c7.append((1,240))
        #sum7=center7
        sum7=sum7/len(c7)
    if len(c8):
        #c8.append((1,240))
        #sum8=center8
        sum8=sum8/len(c8)
    if len(c9):
        #c9.append((1,240))
        sum9=sum9/len(c9)
    if len(c10):
        #c10.append((1,240))
        #sum10=center10
        sum10=sum10/len(c10)
    if len(c11):
        #c11.append((1,240))
        sum11=sum11/len(c11)
    if(count==0):
        sr=sumr
        s0=sum0
        s1=sum1
        s2=sum2
        s3=sum3
        s4=sum4
        s5=sum5
        s6=sum6
        s7=sum7
        s8=sum8
        s9=sum9
        s10=sum10
        s11=sum11
        count=count+1
    else:
        if(s1==sum1 and s2==sum2 and s3==sum3 and s4==sum4 and sr==sumr and s10==sum10):
            if(s5==sum5 and s6==sum6 and s7==sum7 and s8==sum8 and s9==sum9 and s11==sum11):
                check=0
                x=[len(c1),len(c2),len(c3),len(c4),len(c5),len(c6),len(c7),len(c8),len(c9),len(c10),len(c11)]
                y=[s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11]
                '''
                print(x)
                print(y)
                plt.plot(y,x,color='green',marker='o')
                plt.xlabel("Score of Sentences")
                plt.ylabel("No of Sentences")
                plt.title("NO vs Score")
                plt.show()
                print(s7)'''
               
                               
        else:
            s1=sum1
            s2=sum2
            s3=sum3
            s4=sum4
            s5=sum5
            s6=sum6
            s7=sum7
            s8=sum8
            s9=sum9
            s10=sum10
            s11=sum11
            count=count+1
            c1=[]
            c2=[]
            c3=[]
            c4=[]  
            c5=[]
            c6=[]
            c7=[]
            c8=[]
            c9=[]
            c10=[]
            c11=[]




afterSort.sort(key=lambda x:x[1])
afterSort.reverse()
takingSent=[]

if(lenOfPara<30):
    takingWhichSent=takingWhichSent=math.ceil(lenOfPara/3)
else:
    takingWhichSent=10
for i in range(len(afterSort)):
    print(afterSort[i])
    if i<takingWhichSent:
        takingSent.append(afterSort[i][0])

print("\n\nGetting Summary")

print("-------------------------------------------------------------")
takingSent.sort()
for i in takingSent:
    #print(sent[i],end='')
    print(sent[i],end='')

class RBA:
    def retNSent(self):
        global takingSent
        return takingSent
    def retXY(self):
        global x,y
        xy=[]
        xy.append(x)
        xy.append(y)
        return xy